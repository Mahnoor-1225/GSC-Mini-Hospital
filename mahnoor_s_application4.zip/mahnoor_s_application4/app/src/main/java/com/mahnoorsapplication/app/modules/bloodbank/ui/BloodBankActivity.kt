package com.mahnoorsapplication.app.modules.bloodbank.ui

import androidx.activity.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseActivity
import com.mahnoorsapplication.app.databinding.ActivityBloodBankBinding
import com.mahnoorsapplication.app.modules.bloodbank.`data`.viewmodel.BloodBankVM
import kotlin.String
import kotlin.Unit

class BloodBankActivity : BaseActivity<ActivityBloodBankBinding>(R.layout.activity_blood_bank) {
  private val viewModel: BloodBankVM by viewModels<BloodBankVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.bloodBankVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BLOOD_BANK_ACTIVITY"

  }
}
