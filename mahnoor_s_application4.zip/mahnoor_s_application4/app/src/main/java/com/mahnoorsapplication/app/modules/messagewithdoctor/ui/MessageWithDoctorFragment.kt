package com.mahnoorsapplication.app.modules.messagewithdoctor.ui

import android.os.Bundle
import androidx.fragment.app.viewModels
import com.google.android.material.tabs.TabLayoutMediator
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseFragment
import com.mahnoorsapplication.app.databinding.FragmentMessageWithDoctorBinding
import com.mahnoorsapplication.app.modules.messagewithdoctor.`data`.viewmodel.MessageWithDoctorVM
import kotlin.String
import kotlin.Unit

class MessageWithDoctorFragment :
    BaseFragment<FragmentMessageWithDoctorBinding>(R.layout.fragment_message_with_doctor) {
  private val viewModel: MessageWithDoctorVM by viewModels<MessageWithDoctorVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.messageWithDoctorVM = viewModel
    val adapter = MessageWithDoctorFragmentPagerAdapter(childFragmentManager,lifecycle)
    binding.viewPagerViewpager.adapter = adapter
    TabLayoutMediator(binding.tabLayoutTabground,binding.viewPagerViewpager) { tab, position ->
      tab.text = MessageWithDoctorFragmentPagerAdapter.title[position]
      }.attach()
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "MESSAGE_WITH_DOCTOR_FRAGMENT"


      fun getInstance(bundle: Bundle?): MessageWithDoctorFragment {
        val fragment = MessageWithDoctorFragment()
        fragment.arguments = bundle
        return fragment
      }
    }
  }
