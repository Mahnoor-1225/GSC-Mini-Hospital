package com.mahnoorsapplication.app.modules.bookanappointment.ui

import androidx.activity.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseActivity
import com.mahnoorsapplication.app.databinding.ActivityBookAnAppointmentBinding
import com.mahnoorsapplication.app.modules.bookanappointment.`data`.viewmodel.BookAnAppointmentVM
import kotlin.String
import kotlin.Unit

class BookAnAppointmentActivity :
    BaseActivity<ActivityBookAnAppointmentBinding>(R.layout.activity_book_an_appointment) {
  private val viewModel: BookAnAppointmentVM by viewModels<BookAnAppointmentVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.bookAnAppointmentVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BOOK_AN_APPOINTMENT_ACTIVITY"

  }
}
