package com.mahnoorsapplication.app.modules.pharmacy.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class PharmacyModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBloodBank: String? = MyApp.getInstance().resources.getString(R.string.lbl_blood_banks)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOrderquicklyw: String? =
      MyApp.getInstance().resources.getString(R.string.msg_get_in_touch_wi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNearestOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_nearest_one)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeall: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtJamilaSultana: String? =
      MyApp.getInstance().resources.getString(R.string.msg_jamila_sulatan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_15_min_drive)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAvailabilityTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_open)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBloodGroupsV: String? =
      MyApp.getInstance().resources.getString(R.string.msg_blood_groups_v)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeallOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etSearchValue: String? = null
)
