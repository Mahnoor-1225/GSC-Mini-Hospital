package com.mahnoorsapplication.app.modules.loginone.ui

import androidx.activity.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseActivity
import com.mahnoorsapplication.app.databinding.ActivityLoginOneBinding
import com.mahnoorsapplication.app.modules.loginone.`data`.viewmodel.LoginOneVM
import kotlin.String
import kotlin.Unit

class LoginOneActivity : BaseActivity<ActivityLoginOneBinding>(R.layout.activity_login_one) {
  private val viewModel: LoginOneVM by viewModels<LoginOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loginOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "LOGIN_ONE_ACTIVITY"

  }
}
