package com.mahnoorsapplication.app.modules.drdetails.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DrDetailsRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_09_00_am)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_10_00_am)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_11_00_am)

)
