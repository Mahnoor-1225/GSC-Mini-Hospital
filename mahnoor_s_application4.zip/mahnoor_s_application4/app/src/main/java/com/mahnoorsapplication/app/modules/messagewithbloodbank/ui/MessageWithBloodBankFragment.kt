package com.mahnoorsapplication.app.modules.messagewithbloodbank.ui

import android.view.View
import androidx.fragment.app.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseFragment
import com.mahnoorsapplication.app.databinding.FragmentMessageWithBloodBankBinding
import com.mahnoorsapplication.app.modules.messagewithbloodbank.`data`.model.Listprofilethumbna1RowModel
import com.mahnoorsapplication.app.modules.messagewithbloodbank.`data`.viewmodel.MessageWithBloodBankVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class MessageWithBloodBankFragment :
    BaseFragment<FragmentMessageWithBloodBankBinding>(R.layout.fragment_message_with_blood_bank) {
  private val viewModel: MessageWithBloodBankVM by viewModels<MessageWithBloodBankVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val listprofilethumbnaAdapter =
    ListprofilethumbnaAdapter(viewModel.listprofilethumbnaList.value?:mutableListOf())
    binding.recyclerListprofilethumbna.adapter = listprofilethumbnaAdapter
    listprofilethumbnaAdapter.setOnItemClickListener(
    object : ListprofilethumbnaAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : Listprofilethumbna1RowModel) {
        onClickRecyclerListprofilethumbna(view, position, item)
      }
    }
    )
    viewModel.listprofilethumbnaList.observe(requireActivity()) {
      listprofilethumbnaAdapter.updateData(it)
    }
    binding.messageWithBloodBankVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerListprofilethumbna(
    view: View,
    position: Int,
    item: Listprofilethumbna1RowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "MESSAGE_WITH_BLOOD_BANK_FRAGMENT"

  }
}
