package com.mahnoorsapplication.app.modules.bloodbanksinfo.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListtimeOneRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_3_30_pm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReadtimeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_open)

)
