package com.mahnoorsapplication.app.modules.bloodbank.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mahnoorsapplication.app.modules.bloodbank.`data`.model.BloodBankModel
import org.koin.core.KoinComponent

class BloodBankVM : ViewModel(), KoinComponent {
  val bloodBankModel: MutableLiveData<BloodBankModel> = MutableLiveData(BloodBankModel())

  var navArguments: Bundle? = null
}
