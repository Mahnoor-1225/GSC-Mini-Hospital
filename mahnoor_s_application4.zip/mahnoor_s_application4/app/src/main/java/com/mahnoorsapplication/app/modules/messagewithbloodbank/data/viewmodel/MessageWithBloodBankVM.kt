package com.mahnoorsapplication.app.modules.messagewithbloodbank.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mahnoorsapplication.app.modules.messagewithbloodbank.`data`.model.Listprofilethumbna1RowModel
import com.mahnoorsapplication.app.modules.messagewithbloodbank.`data`.model.MessageWithBloodBankModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class MessageWithBloodBankVM : ViewModel(), KoinComponent {
  val messageWithBloodBankModel: MutableLiveData<MessageWithBloodBankModel> =
      MutableLiveData(MessageWithBloodBankModel())

  var navArguments: Bundle? = null

  val listprofilethumbnaList: MutableLiveData<MutableList<Listprofilethumbna1RowModel>> =
      MutableLiveData(mutableListOf())
}
