package com.mahnoorsapplication.app.modules.messagewithdoctor1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mahnoorsapplication.app.modules.messagewithdoctor1.`data`.model.ListprofilethumbnaRowModel
import com.mahnoorsapplication.app.modules.messagewithdoctor1.`data`.model.MessageWithDoctor1Model
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class MessageWithDoctor1VM : ViewModel(), KoinComponent {
  val messageWithDoctor1Model: MutableLiveData<MessageWithDoctor1Model> =
      MutableLiveData(MessageWithDoctor1Model())

  var navArguments: Bundle? = null

  val listprofilethumbnaList: MutableLiveData<MutableList<ListprofilethumbnaRowModel>> =
      MutableLiveData(mutableListOf())
}
