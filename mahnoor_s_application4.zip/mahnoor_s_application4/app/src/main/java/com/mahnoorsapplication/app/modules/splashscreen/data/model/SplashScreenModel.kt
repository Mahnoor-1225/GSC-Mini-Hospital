package com.mahnoorsapplication.app.modules.splashscreen.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class SplashScreenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMH: String? = MyApp.getInstance().resources.getString(R.string.lbl_mh)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMiniHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_mini_hospital)

)
