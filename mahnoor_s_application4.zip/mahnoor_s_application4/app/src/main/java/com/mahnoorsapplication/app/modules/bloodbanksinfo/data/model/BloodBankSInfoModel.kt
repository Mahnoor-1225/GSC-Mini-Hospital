package com.mahnoorsapplication.app.modules.bloodbanksinfo.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class BloodBankSInfoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtArticles: String? = MyApp.getInstance().resources.getString(R.string.lbl_blood_banks)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPopularArticle: String? =
      MyApp.getInstance().resources.getString(R.string.msg_popular_article)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNeareestOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_nearest)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInCity: String? = MyApp.getInstance().resources.getString(R.string.lbl_in_city)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInCountry: String? = MyApp.getInstance().resources.getString(R.string.lbl_in_country)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTrendingArticl: String? =
      MyApp.getInstance().resources.getString(R.string.msg_trending_articl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeall: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInCityOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_in_city)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeallOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTheHealthiest: String? =
      MyApp.getInstance().resources.getString(R.string.msg_ngo_for_blood_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTraditionalHer: String? =
      MyApp.getInstance().resources.getString(R.string.msg_ngo_blood_ii)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_3_30_pm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReadtime: String? = MyApp.getInstance().resources.getString(R.string.lbl_open)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_nearest2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sundus_foundati2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCovidninteen: String? = MyApp.getInstance().resources.getString(R.string.lbl_nearest)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTheHorrorOfT: String? =
      MyApp.getInstance().resources.getString(R.string.msg_jamila_sultana)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_3_30_pm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReadtimeThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_open)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etSearchValue: String? = null
)
