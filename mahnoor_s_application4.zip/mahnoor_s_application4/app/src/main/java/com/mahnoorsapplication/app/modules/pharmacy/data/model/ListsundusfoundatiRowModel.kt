package com.mahnoorsapplication.app.modules.pharmacy.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListsundusfoundatiRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtSundusFoundati: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sundus_foundati)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_20_min_drive)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAvailability: String? = MyApp.getInstance().resources.getString(R.string.lbl_open)

)
