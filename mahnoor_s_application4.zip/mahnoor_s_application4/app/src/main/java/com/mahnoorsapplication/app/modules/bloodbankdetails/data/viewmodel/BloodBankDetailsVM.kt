package com.mahnoorsapplication.app.modules.bloodbankdetails.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mahnoorsapplication.app.modules.bloodbankdetails.`data`.model.BloodBankDetailsModel
import org.koin.core.KoinComponent

class BloodBankDetailsVM : ViewModel(), KoinComponent {
  val bloodBankDetailsModel: MutableLiveData<BloodBankDetailsModel> =
      MutableLiveData(BloodBankDetailsModel())

  var navArguments: Bundle? = null
}
