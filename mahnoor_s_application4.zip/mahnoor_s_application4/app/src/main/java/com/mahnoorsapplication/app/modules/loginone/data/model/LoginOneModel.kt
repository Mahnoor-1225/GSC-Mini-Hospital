package com.mahnoorsapplication.app.modules.loginone.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class LoginOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMH: String? = MyApp.getInstance().resources.getString(R.string.lbl_mh)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroupSix: String? = MyApp.getInstance().resources.getString(R.string.lbl_mini_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWelcometoHiDo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_welcome_to_mini)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSignintocont: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sign_in_to_cont)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtForgotPassword: String? =
      MyApp.getInstance().resources.getString(R.string.msg_forgot_password)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtConfirmation: String? =
      MyApp.getInstance().resources.getString(R.string.msg_don_t_have_an_a)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etEmailFormValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etPasswordFormValue: String? = null
)
