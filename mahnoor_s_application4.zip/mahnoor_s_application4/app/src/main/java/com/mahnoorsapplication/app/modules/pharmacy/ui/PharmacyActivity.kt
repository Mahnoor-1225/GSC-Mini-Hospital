package com.mahnoorsapplication.app.modules.pharmacy.ui

import android.view.View
import androidx.activity.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseActivity
import com.mahnoorsapplication.app.databinding.ActivityPharmacyBinding
import com.mahnoorsapplication.app.modules.pharmacy.`data`.model.ListobhcombiRowModel
import com.mahnoorsapplication.app.modules.pharmacy.`data`.model.ListsundusfoundatiRowModel
import com.mahnoorsapplication.app.modules.pharmacy.`data`.viewmodel.PharmacyVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class PharmacyActivity : BaseActivity<ActivityPharmacyBinding>(R.layout.activity_pharmacy) {
  private val viewModel: PharmacyVM by viewModels<PharmacyVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val listsundusfoundatiAdapter =
    ListsundusfoundatiAdapter(viewModel.listsundusfoundatiList.value?:mutableListOf())
    binding.recyclerListsundusfoundati.adapter = listsundusfoundatiAdapter
    listsundusfoundatiAdapter.setOnItemClickListener(
    object : ListsundusfoundatiAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListsundusfoundatiRowModel) {
        onClickRecyclerListsundusfoundati(view, position, item)
      }
    }
    )
    viewModel.listsundusfoundatiList.observe(this) {
      listsundusfoundatiAdapter.updateData(it)
    }
    val listobhcombiAdapter =
    ListobhcombiAdapter(viewModel.listobhcombiList.value?:mutableListOf())
    binding.recyclerListobhcombi.adapter = listobhcombiAdapter
    listobhcombiAdapter.setOnItemClickListener(
    object : ListobhcombiAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListobhcombiRowModel) {
        onClickRecyclerListobhcombi(view, position, item)
      }
    }
    )
    viewModel.listobhcombiList.observe(this) {
      listobhcombiAdapter.updateData(it)
    }
    binding.pharmacyVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerListsundusfoundati(
    view: View,
    position: Int,
    item: ListsundusfoundatiRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListobhcombi(
    view: View,
    position: Int,
    item: ListobhcombiRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "PHARMACY_ACTIVITY"

  }
}
