package com.mahnoorsapplication.app.modules.signup.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class SignupModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMH: String? = MyApp.getInstance().resources.getString(R.string.lbl_mh)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroupThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_mini_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLetsGetStart: String? =
      MyApp.getInstance().resources.getString(R.string.msg_let_s_get_start)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCreateannewa: String? =
      MyApp.getInstance().resources.getString(R.string.msg_create_an_new_a)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtConfirmation: String? =
      MyApp.getInstance().resources.getString(R.string.msg_have_an_account)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etFullNameFormValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etEmailFormValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etPasswordFormValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etPasswordAgainValue: String? = null
)
