package com.mahnoorsapplication.app.modules.pharmacy.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.databinding.RowListsundusfoundatiBinding
import com.mahnoorsapplication.app.modules.pharmacy.`data`.model.ListsundusfoundatiRowModel
import kotlin.Int
import kotlin.collections.List

class ListsundusfoundatiAdapter(
  var list: List<ListsundusfoundatiRowModel>
) : RecyclerView.Adapter<ListsundusfoundatiAdapter.RowListsundusfoundatiVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListsundusfoundatiVH {
    val
        view=LayoutInflater.from(parent.context).inflate(R.layout.row_listsundusfoundati,parent,false)
    return RowListsundusfoundatiVH(view)
  }

  override fun onBindViewHolder(holder: RowListsundusfoundatiVH, position: Int) {
    val listsundusfoundatiRowModel = ListsundusfoundatiRowModel()
    // TODO uncomment following line after integration with data source
    // val listsundusfoundatiRowModel = list[position]
    holder.binding.listsundusfoundatiRowModel = listsundusfoundatiRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListsundusfoundatiRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListsundusfoundatiRowModel
    ) {
    }
  }

  inner class RowListsundusfoundatiVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListsundusfoundatiBinding = RowListsundusfoundatiBinding.bind(itemView)
  }
}
