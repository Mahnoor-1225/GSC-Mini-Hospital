package com.mahnoorsapplication.app.modules.bloodbanksinfo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mahnoorsapplication.app.modules.bloodbanksinfo.`data`.model.BloodBankSInfoModel
import com.mahnoorsapplication.app.modules.bloodbanksinfo.`data`.model.ListtimeOneRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class BloodBankSInfoVM : ViewModel(), KoinComponent {
  val bloodBankSInfoModel: MutableLiveData<BloodBankSInfoModel> =
      MutableLiveData(BloodBankSInfoModel())

  var navArguments: Bundle? = null

  val listtimeOneList: MutableLiveData<MutableList<ListtimeOneRowModel>> =
      MutableLiveData(mutableListOf())
}
