package com.mahnoorsapplication.app.modules.dashboard.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DashboardModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtFindyourdesir: String? =
      MyApp.getInstance().resources.getString(R.string.msg_select_your_des)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEarlyprotectio: String? =
      MyApp.getInstance().resources.getString(R.string.msg_register_as_a_b)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTopDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_top_doctors)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeall: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBloodBanks: String? = MyApp.getInstance().resources.getString(R.string.lbl_blood_banks)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeallOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTheHealthiest: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sultana_foundat)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_jun_10_2021)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReadtime: String? = MyApp.getInstance().resources.getString(R.string.lbl_active)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etSearchValue: String? = null
)
