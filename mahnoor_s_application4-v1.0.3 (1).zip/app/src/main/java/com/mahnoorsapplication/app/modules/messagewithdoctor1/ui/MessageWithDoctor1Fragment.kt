package com.mahnoorsapplication.app.modules.messagewithdoctor1.ui

import android.view.View
import androidx.fragment.app.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseFragment
import com.mahnoorsapplication.app.databinding.FragmentMessageWithDoctor1Binding
import com.mahnoorsapplication.app.modules.messagewithdoctor1.`data`.model.ListprofilethumbnaRowModel
import com.mahnoorsapplication.app.modules.messagewithdoctor1.`data`.viewmodel.MessageWithDoctor1VM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class MessageWithDoctor1Fragment :
    BaseFragment<FragmentMessageWithDoctor1Binding>(R.layout.fragment_message_with_doctor1) {
  private val viewModel: MessageWithDoctor1VM by viewModels<MessageWithDoctor1VM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val listprofilethumbnaAdapter =
    ListprofilethumbnaAdapter(viewModel.listprofilethumbnaList.value?:mutableListOf())
    binding.recyclerListprofilethumbna.adapter = listprofilethumbnaAdapter
    listprofilethumbnaAdapter.setOnItemClickListener(
    object : ListprofilethumbnaAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListprofilethumbnaRowModel) {
        onClickRecyclerListprofilethumbna(view, position, item)
      }
    }
    )
    viewModel.listprofilethumbnaList.observe(requireActivity()) {
      listprofilethumbnaAdapter.updateData(it)
    }
    binding.messageWithDoctor1VM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerListprofilethumbna(
    view: View,
    position: Int,
    item: ListprofilethumbnaRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "MESSAGE_WITH_DOCTOR1FRAGMENT"

  }
}
