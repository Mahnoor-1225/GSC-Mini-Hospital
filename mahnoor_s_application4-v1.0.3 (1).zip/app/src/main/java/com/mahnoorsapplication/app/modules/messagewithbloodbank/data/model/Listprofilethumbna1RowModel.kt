package com.mahnoorsapplication.app.modules.messagewithbloodbank.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class Listprofilethumbna1RowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtSundusFoundati: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sundus_foundati)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_10_24)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtIdonthavean: String? =
      MyApp.getInstance().resources.getString(R.string.msg_i_am_from_xyz_p)

)
