package com.mahnoorsapplication.app.modules.bloodbank.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class BloodBankModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBloodBank: String? = MyApp.getInstance().resources.getString(R.string.lbl_blood_bank)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etSearchValue: String? = null
)
