package com.mahnoorsapplication.app.modules.settigns.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class SettignsRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDonatedOn: String? = MyApp.getInstance().resources.getString(R.string.lbl_donated)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDonatedonOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_2_03_23)

)
