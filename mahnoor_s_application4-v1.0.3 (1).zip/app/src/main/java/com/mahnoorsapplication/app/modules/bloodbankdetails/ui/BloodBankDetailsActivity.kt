package com.mahnoorsapplication.app.modules.bloodbankdetails.ui

import androidx.activity.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseActivity
import com.mahnoorsapplication.app.databinding.ActivityBloodBankDetailsBinding
import com.mahnoorsapplication.app.modules.bloodbankdetails.`data`.viewmodel.BloodBankDetailsVM
import kotlin.String
import kotlin.Unit

class BloodBankDetailsActivity :
    BaseActivity<ActivityBloodBankDetailsBinding>(R.layout.activity_blood_bank_details) {
  private val viewModel: BloodBankDetailsVM by viewModels<BloodBankDetailsVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.bloodBankDetailsVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BLOOD_BANK_DETAILS_ACTIVITY"

  }
}
