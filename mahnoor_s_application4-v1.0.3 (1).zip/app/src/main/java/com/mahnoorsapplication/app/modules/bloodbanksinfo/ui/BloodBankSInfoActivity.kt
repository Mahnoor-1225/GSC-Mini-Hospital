package com.mahnoorsapplication.app.modules.bloodbanksinfo.ui

import android.view.View
import androidx.activity.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseActivity
import com.mahnoorsapplication.app.databinding.ActivityBloodBankSInfoBinding
import com.mahnoorsapplication.app.modules.bloodbanksinfo.`data`.model.ListtimeOneRowModel
import com.mahnoorsapplication.app.modules.bloodbanksinfo.`data`.viewmodel.BloodBankSInfoVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class BloodBankSInfoActivity :
    BaseActivity<ActivityBloodBankSInfoBinding>(R.layout.activity_blood_bank_s_info) {
  private val viewModel: BloodBankSInfoVM by viewModels<BloodBankSInfoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val listtimeOneAdapter =
    ListtimeOneAdapter(viewModel.listtimeOneList.value?:mutableListOf())
    binding.recyclerListtimeOne.adapter = listtimeOneAdapter
    listtimeOneAdapter.setOnItemClickListener(
    object : ListtimeOneAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListtimeOneRowModel) {
        onClickRecyclerListtimeOne(view, position, item)
      }
    }
    )
    viewModel.listtimeOneList.observe(this) {
      listtimeOneAdapter.updateData(it)
    }
    binding.bloodBankSInfoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerListtimeOne(
    view: View,
    position: Int,
    item: ListtimeOneRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "BLOOD_BANK_S_INFO_ACTIVITY"

  }
}
