package com.mahnoorsapplication.app.modules.pharmacy.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mahnoorsapplication.app.modules.pharmacy.`data`.model.ListobhcombiRowModel
import com.mahnoorsapplication.app.modules.pharmacy.`data`.model.ListsundusfoundatiRowModel
import com.mahnoorsapplication.app.modules.pharmacy.`data`.model.PharmacyModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class PharmacyVM : ViewModel(), KoinComponent {
  val pharmacyModel: MutableLiveData<PharmacyModel> = MutableLiveData(PharmacyModel())

  var navArguments: Bundle? = null

  val listsundusfoundatiList: MutableLiveData<MutableList<ListsundusfoundatiRowModel>> =
      MutableLiveData(mutableListOf())

  val listobhcombiList: MutableLiveData<MutableList<ListobhcombiRowModel>> =
      MutableLiveData(mutableListOf())
}
