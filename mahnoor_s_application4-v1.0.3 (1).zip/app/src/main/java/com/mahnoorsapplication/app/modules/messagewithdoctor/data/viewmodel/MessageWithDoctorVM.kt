package com.mahnoorsapplication.app.modules.messagewithdoctor.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mahnoorsapplication.app.modules.messagewithdoctor.`data`.model.MessageWithDoctorModel
import org.koin.core.KoinComponent

class MessageWithDoctorVM : ViewModel(), KoinComponent {
  val messageWithDoctorModel: MutableLiveData<MessageWithDoctorModel> =
      MutableLiveData(MessageWithDoctorModel())

  var navArguments: Bundle? = null
}
