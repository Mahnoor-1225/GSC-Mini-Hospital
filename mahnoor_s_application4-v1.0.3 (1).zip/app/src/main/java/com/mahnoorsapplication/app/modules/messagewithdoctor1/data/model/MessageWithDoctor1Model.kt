package com.mahnoorsapplication.app.modules.messagewithdoctor1.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class MessageWithDoctor1Model(
  /**
   * TODO Replace with dynamic value
   */
  var txtDrMariaElena: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_dr_maria_elena)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_57)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoyouhavefev: String? =
      MyApp.getInstance().resources.getString(R.string.msg_do_you_have_fev)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDrMariaElenaOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_dr_maria_elena)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_57)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoyouhavefevOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_do_you_have_fev)

)
