package com.mahnoorsapplication.app.modules.messagewithbloodbank.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class MessageWithBloodBankModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtNGOBloodII: String? = MyApp.getInstance().resources.getString(R.string.lbl_ngo_blood_ii)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_57)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoyouhavefev: String? =
      MyApp.getInstance().resources.getString(R.string.msg_i_have_received)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_57)

)
