package com.mahnoorsapplication.app.modules.drdetails.ui

import android.view.View
import androidx.activity.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseActivity
import com.mahnoorsapplication.app.databinding.ActivityDrDetailsBinding
import com.mahnoorsapplication.app.modules.drdetails.`data`.model.DrDetailsRowModel
import com.mahnoorsapplication.app.modules.drdetails.`data`.viewmodel.DrDetailsVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class DrDetailsActivity : BaseActivity<ActivityDrDetailsBinding>(R.layout.activity_dr_details) {
  private val viewModel: DrDetailsVM by viewModels<DrDetailsVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val drDetailsAdapter = DrDetailsAdapter(viewModel.drDetailsList.value?:mutableListOf())
    binding.recyclerDrDetails.adapter = drDetailsAdapter
    drDetailsAdapter.setOnItemClickListener(
    object : DrDetailsAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : DrDetailsRowModel) {
        onClickRecyclerDrDetails(view, position, item)
      }
    }
    )
    viewModel.drDetailsList.observe(this) {
      drDetailsAdapter.updateData(it)
    }
    binding.drDetailsVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerDrDetails(
    view: View,
    position: Int,
    item: DrDetailsRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "DR_DETAILS_ACTIVITY"

  }
}
