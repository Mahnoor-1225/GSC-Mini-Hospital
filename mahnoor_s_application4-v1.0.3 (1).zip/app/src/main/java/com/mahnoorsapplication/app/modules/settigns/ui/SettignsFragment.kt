package com.mahnoorsapplication.app.modules.settigns.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.base.BaseFragment
import com.mahnoorsapplication.app.appcomponents.views.ImagePickerFragmentDialog
import com.mahnoorsapplication.app.databinding.FragmentSettignsBinding
import com.mahnoorsapplication.app.modules.settigns.`data`.model.SettignsRowModel
import com.mahnoorsapplication.app.modules.settigns.`data`.viewmodel.SettignsVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class SettignsFragment : BaseFragment<FragmentSettignsBinding>(R.layout.fragment_settigns) {
  private val viewModel: SettignsVM by viewModels<SettignsVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val settignsAdapter = SettignsAdapter(viewModel.settignsList.value?:mutableListOf())
    binding.recyclerSettigns.adapter = settignsAdapter
    settignsAdapter.setOnItemClickListener(
    object : SettignsAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : SettignsRowModel) {
        onClickRecyclerSettigns(view, position, item)
      }
    }
    )
    viewModel.settignsList.observe(requireActivity()) {
      settignsAdapter.updateData(it)
    }
    binding.settignsVM = viewModel
  }

  override fun setUpClicks(): Unit {


    binding.btnCamera.setOnClickListener {
      ImagePickerFragmentDialog().show(childFragmentManager)
      { path ->//TODO HANDLE DATA
      }

    }
  }

  fun onClickRecyclerSettigns(
    view: View,
    position: Int,
    item: SettignsRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "SETTIGNS_FRAGMENT"


    fun getInstance(bundle: Bundle?): SettignsFragment {
      val fragment = SettignsFragment()
      fragment.arguments = bundle
      return fragment
    }
  }
}
