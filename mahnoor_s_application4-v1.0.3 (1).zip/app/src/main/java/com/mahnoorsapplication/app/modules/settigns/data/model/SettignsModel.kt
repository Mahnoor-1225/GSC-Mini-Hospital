package com.mahnoorsapplication.app.modules.settigns.`data`.model

import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class SettignsModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAmeliaRenata: String? = MyApp.getInstance().resources.getString(R.string.lbl_amelia_renata)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWeight: String? = MyApp.getInstance().resources.getString(R.string.lbl_weight)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWeightvalue: String? = MyApp.getInstance().resources.getString(R.string.lbl_103lbs)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMySaved: String? = MyApp.getInstance().resources.getString(R.string.msg_my_donation_his)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAppointmnet: String? = MyApp.getInstance().resources.getString(R.string.lbl_appointmnet)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPaymentMethod: String? =
      MyApp.getInstance().resources.getString(R.string.msg_blood_group_boo)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFAQs: String? = MyApp.getInstance().resources.getString(R.string.lbl_groups)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHelp: String? = MyApp.getInstance().resources.getString(R.string.lbl_help)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHelpOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_location)

)
