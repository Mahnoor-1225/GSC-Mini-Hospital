package com.mahnoorsapplication.app.modules.pharmacy.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.databinding.RowListobhcombiBinding
import com.mahnoorsapplication.app.modules.pharmacy.`data`.model.ListobhcombiRowModel
import kotlin.Int
import kotlin.collections.List

class ListobhcombiAdapter(
  var list: List<ListobhcombiRowModel>
) : RecyclerView.Adapter<ListobhcombiAdapter.RowListobhcombiVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListobhcombiVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listobhcombi,parent,false)
    return RowListobhcombiVH(view)
  }

  override fun onBindViewHolder(holder: RowListobhcombiVH, position: Int) {
    val listobhcombiRowModel = ListobhcombiRowModel()
    // TODO uncomment following line after integration with data source
    // val listobhcombiRowModel = list[position]
    holder.binding.listobhcombiRowModel = listobhcombiRowModel
  }

  override fun getItemCount(): Int = 3
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListobhcombiRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListobhcombiRowModel
    ) {
    }
  }

  inner class RowListobhcombiVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListobhcombiBinding = RowListobhcombiBinding.bind(itemView)
  }
}
