package com.mahnoorsapplication.app.modules.messagewithdoctor1.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mahnoorsapplication.app.R
import com.mahnoorsapplication.app.databinding.RowListprofilethumbnaBinding
import com.mahnoorsapplication.app.modules.messagewithdoctor1.`data`.model.ListprofilethumbnaRowModel
import kotlin.Int
import kotlin.collections.List

class ListprofilethumbnaAdapter(
  var list: List<ListprofilethumbnaRowModel>
) : RecyclerView.Adapter<ListprofilethumbnaAdapter.RowListprofilethumbnaVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListprofilethumbnaVH {
    val
        view=LayoutInflater.from(parent.context).inflate(R.layout.row_listprofilethumbna,parent,false)
    return RowListprofilethumbnaVH(view)
  }

  override fun onBindViewHolder(holder: RowListprofilethumbnaVH, position: Int) {
    val listprofilethumbnaRowModel = ListprofilethumbnaRowModel()
    // TODO uncomment following line after integration with data source
    // val listprofilethumbnaRowModel = list[position]
    holder.binding.listprofilethumbnaRowModel = listprofilethumbnaRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListprofilethumbnaRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListprofilethumbnaRowModel
    ) {
    }
  }

  inner class RowListprofilethumbnaVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListprofilethumbnaBinding = RowListprofilethumbnaBinding.bind(itemView)
  }
}
